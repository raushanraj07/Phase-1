package com.innerclass;

public abstract class AnonymousInnerClass {
public abstract void display();
}
