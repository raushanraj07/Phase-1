package packpublic;

public class PublicAccessModifier {
   public void display() {
	   System.out.println("This is public access modifier");
   
   }
}
