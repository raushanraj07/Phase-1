package packpublic1;
import packpublic.*;
public class AccessModifier3 {

	public static void main(String[] args) {
		
          PublicAccessModifier obj= new PublicAccessModifier();
          obj.display();
	}

}
