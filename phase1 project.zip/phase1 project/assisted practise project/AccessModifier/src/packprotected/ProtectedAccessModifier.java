package packprotected;

public class ProtectedAccessModifier {
protected void display() {
	System.out.println("this is protected access modifier");
	
}
}
