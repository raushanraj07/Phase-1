package com.accessmodifier;

public class DefAccessModifier {

	void display() {
		System.out.println("Default Access Modifier is used");
		
	}
}