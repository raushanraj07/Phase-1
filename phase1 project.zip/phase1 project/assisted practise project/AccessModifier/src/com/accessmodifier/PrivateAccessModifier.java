package com.accessmodifier;

public class PrivateAccessModifier {

	private void display() {
		System.out.println("you are using private access modifier");
		
		
	}
}
