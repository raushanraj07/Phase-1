package com.accessmodifier;

public class AccessModifier {

	public static void main(String[] args) {
		System.out.println("default access modifier");
		DefAccessModifier obj=new DefAccessModifier();
		obj.display();
		

	}

}
