package packprotected1;
import packprotected.*;
public class AccessModofier2 extends ProtectedAccessModifier {

	public static void main(String[] args) {
		
          AccessModofier2 obj= new AccessModofier2();
          obj.display();
	}

}
