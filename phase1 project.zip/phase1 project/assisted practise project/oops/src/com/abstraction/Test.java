package com.abstraction;

public class Test {
    public static void main(String[] args) 
    { 
        
        Shape s1= new Rectangle("Brown", 5, 2);

        System.out.println(s1.toString()); 
    } 

}
